$(document).ready(function () {
  // fetching data from OBCSensors
  $.ajax({
    type: "GET",
    url: "../OBCSensors.json",
    success: function (response) {
      response.forEach((data) => {
        $("#batteryTemp_1").html(data["Battery Temperature 1"]);
        $("#batteryTemp_2").html(data["Battery Temperature 2"]);
        $("#batteryTemp_3").html(data["Battery Temperature 3"]);
        $("#batteryTemp_4").html(data["Battery Temperature 4"]);
        $("#boardTemp").html(data["Board Temperature"]);
      });
    },
  });

  // fetching data from BME280 sensor
  $.ajax({
    type: "GET",
    url: "../BME280.json",
    success: function (result) {
      result.forEach((bme) => {
        $("#ambientTemp").html(bme["Ambient Temperature"]);
        $("#humidity").html(bme.Humidity);
        $("#pressure").html(bme.pressure);
        $("#altitude").html(bme.altitude);
      });
    },
  });

  // fetching image from image.json
  $.ajax({
    type: "GET",
    url: "../image.json",
    success: function (res) {
      res.forEach((element) => {
        $("#image").prepend('<img src="' + element.path + '" />');
      });
    },
  });
});
